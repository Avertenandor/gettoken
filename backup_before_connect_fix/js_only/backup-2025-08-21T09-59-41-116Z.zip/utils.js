// Глобальные утилиты для всех скриптов
function id(i){return document.getElementById(i);}
function log(msg, type='info'){console[type==='error'?'error':'log'](msg);}
